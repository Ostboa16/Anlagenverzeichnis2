package model;

import data.AnlagenBL;
import data.AnlagenEnum;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import javax.swing.JOptionPane;
import javax.swing.table.AbstractTableModel;

public class AnlagenModel extends AbstractTableModel {

    public static List<AnlagenBL> list = new ArrayList<>();
    private static final String COMMA_DELIMITER = ";";

    public AnlagenModel(ArrayList list){
        this.list = list;
        this.fireTableDataChanged();
    }
    
    @Override
    public int getRowCount() {
        return list.size();
    }

    @Override
    public int getColumnCount() {
        return AnlagenEnum.values().length;
    }

    @Override
    public String getColumnName(int i) {
        return AnlagenEnum.values()[i].getName();
    }

    @Override
    public Object getValueAt(int row, int col) {
        AnlagenBL a = list.get(row);
        AnlagenEnum enumIndex = AnlagenEnum.values()[col];

        switch (enumIndex) {
            case BEZEICHNUNG:
                return a.getBezeichnung();
            case AK:
                return a.getAk();
            case INBETRIEBNAHME:
                return a.getInbetriebnahme();
            case ND:
                return a.getND();
        }
        return "?";
    }
    
    public static ArrayList<AnlagenBL> load(String fileName) throws FileNotFoundException {
        FileReader file = new FileReader(fileName);
        ArrayList<AnlagenBL> objs = new ArrayList();
        Scanner in = null;

        in = new Scanner(file);
        in.nextLine();
        while (in.hasNextLine()) {
            String line = in.nextLine();
            AnlagenBL aObj = null;
            String[] tokens = line.split(COMMA_DELIMITER);
            if (tokens.length > 0) {
                AnlagenBL cObj = new AnlagenBL(tokens[0], (tokens[1]),
                        (tokens[2]), (tokens[3]));
                objs.add(cObj);
            }
            
        }
        try {
            if (in != null) {
                in.close();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }

        return objs;
    }

}
