package data;

public enum AnlagenEnum {
    BEZEICHNUNG("Bezeichnung"),
    AK("AK"),
    INBETRIEBNAHME("Inbetriebnahme"),
    ND("ND"),
    BISHND("bish. ND"),
    BISHAFA("AfA bisher"),
    WERT("Wert vor ..."),
    AFADJ("AfA d. J."),
    BW("BW 31.12.");
    
    private String name;
    
     private AnlagenEnum(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
