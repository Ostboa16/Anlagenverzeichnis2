package data;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class AnlagenBL {

    String bezeichnung;
    String  nd;
    String ak;
    String inbetriebnahme;

    double bishND, bishAfA, wert, afaDJ, bw;

    public AnlagenBL(String bezeichnung, String ak, String inbetriebnahme, String nd) {
        this.bezeichnung = bezeichnung;
        this.ak = ak;
        this.inbetriebnahme = inbetriebnahme;
        this.nd = nd;
    }

    public String getBezeichnung() {
        return bezeichnung;
    }

    public String getAk() {
        return ak;
    }

    public String getInbetriebnahme() {
        return inbetriebnahme;
    }

    public String getND() {
        return nd;
    }

    //Berechnungen:
    public double calcBishND() {
        
    }

    public double calcBishAfA() {
        
    }

    public double calcWert() {
        
    }

    public double calcAfaDJ() {
        
    }

    public double calcBw() {
        
    }

}
